//
//  EigenWrapper.h
//  EigenWrapper
//
//  Created by Anna Labellarte on 25/08/22.
//

#import <Foundation/Foundation.h>

//! Project version number for EigenWrapper.
FOUNDATION_EXPORT double EigenWrapperVersionNumber;

//! Project version string for EigenWrapper.
FOUNDATION_EXPORT const unsigned char EigenWrapperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EigenWrapper/PublicHeader.h>


#import <EigenWrapper/EigenHelper.h>
