//
//  EigenHelper.h
//  EigenWrapper
//
//  Created by Anna Labellarte on 25/08/22.
//
#import <Foundation/Foundation.h>
@interface EigenHelper : NSObject
+ (double) testMethod;
+ (double) testMethodEigen;
@end
